# BazarHQ Import CSV Button Fix

Replace:
- src/pages/merchant/products.jsx

Add:
- public/samples/product-import-template.csv

After replacement, the Products page top-right action area will show:
- Import CSV
- Export CSV
- Add product

No extra SQL is needed if you already ran the scenario 1-6 SQL. The CSV import itself inserts directly into the existing `products` table for the current store.
